(function() {
  $("#filterrific_results").html("<%= js %>");

}).call(this);
